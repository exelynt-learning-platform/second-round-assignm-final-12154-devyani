package com.ecommerce.controller;

import com.ecommerce.entity.Cart;
import com.ecommerce.service.CartService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/add/{productId}")
    public Cart addProduct(@PathVariable Long productId, @RequestParam String username) {
        return cartService.addProduct(username, productId);
    }

    @DeleteMapping("/remove/{productId}")
    public Cart removeProduct(@PathVariable Long productId, @RequestParam String username) {
        return cartService.removeProduct(username, productId);
    }

    @GetMapping
    public Cart viewCart(@RequestParam String username) {
        return cartService.getCart(username);
    }
}

package com.ecommerce.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username; 

    @ManyToMany
    private List<Product> products;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

	
}
